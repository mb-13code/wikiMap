from titelFotoLinks import getData

class Node:
    def __init__(self, extension):
        self.extension = extension
        self.data = getData(self.extension)
        self.children = self.data['urls']
        self.image_url = self.data['image']
        self.title = self.data['title']

    def __eq__(self, other):
        if self.extension != other.extension or self.title != other.title:
            return False
        elif self.image_url != other.image_url or self.children != other.children:
            return False
        else:
            return True

    def isChildOf(self, parent):
        return self.extension in parent.children


