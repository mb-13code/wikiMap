import requests
from bs4 import BeautifulSoup
import re

def getData(root):

    # Scrape site and create soup object
    root_url = f'https://en.wikipedia.org{root}'
    source = requests.get(root_url).text
    soup = BeautifulSoup(source, 'lxml')

    first_div = soup.find('div', id="bodyContent")

    # Get title and image
    try:
        title = soup.find('span', class_="mw-page-title-main").get_text()

    except AttributeError:
        return {'title': root, 'image': None, 'urls': None}

    try:
        image = f"https:{first_div.find('table', class_='infobox').find('a', class_='image').find('img')['src']}"

    except AttributeError:
        return {'title': title, 'image': None, 'urls': None}

    # Retreive urls
    linkpatt = re.compile(r'^\/wiki\/[^:]+$')
    links = []
    for link in soup.findAll('a', href=linkpatt):
        if link['href'] != '/wiki/Main_Page' and link['href'] != root:
            if link['href'] not in links:
                links.append(link['href'])

    data = {'title': title, 'image': image, 'urls': tuple(links)}
    return data

def download_img(url, img_name):
    img_data = requests.get(url).content
    with open(f'{img_name}.jpg', 'wb') as handler:
        handler.write(img_data)
    return
