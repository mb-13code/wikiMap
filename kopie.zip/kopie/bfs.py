from wikiClass import Node

def initiate(url0):
    root = Node(url0)

    with open('V.txt', 'w') as Vf:
        Vf.write(url0)
    with open('Q.txt', 'w') as Qf:
        Qf.write(url0)
    with open('A.txt', 'w') as Af:
        Af.write('')
    with open('VT.txt', 'w') as VTf:
        VTf.write(root.title)
    with open('inf.txt', 'w') as inff:
        lvl = {url0: 0}
        inff.write(str(lvl))

def openProgress():

    with open('V.txt', 'r') as Vf:
        V = [line.strip() for line in Vf.readlines()]
    with open('Q.txt', 'r') as Qf:
        Q = [line.strip() for line in Qf.readlines()]
    with open('A.txt', 'r') as Af:
        A = [line.strip() for line in Af.readlines()]
    with open('VT.txt', 'r') as VTf:
        VT = [line.strip() for line in VTf.readlines()]
        len0 = len(VT)
    with open('inf.txt', 'r') as inff:
        lvl = eval(inff.read())

    return V, Q, A, VT, len0, lvl

def maakBoom(N):

    # Retreive progress
    V, Q, A, VT, len0, lvl = openProgress()

    # BFS
    while len(VT) <= len0 + N:

        v_ext = Q[-1]
        Q.pop()

        v = Node(v_ext)
        VT.append(v.title)
        print(VT)

        try:
            for w in v.children:
                if w not in V:
                    V.append(w)
                    A.append((v_ext, w))
                    Q.insert(0, w)

                    lvl[w] = lvl[v_ext] + 1
                elif (v_ext, w) not in A:
                    A.append((v_ext, w))


        except TypeError:
            continue

    print(len(A))

    # Store progress
    with open('V.txt', 'w') as Vf:
        for node in V:
            Vf.write(str(node) + '\n')
    with open('Q.txt', 'w') as Qf:
        for node in Q:
            Qf.write(str(node) + '\n')
    with open('A.txt', 'w') as Af:
        for edge in A:
            Af.write(str(edge) + '\n')
    with open('VT.txt', 'w') as VTf:
        for title in VT:
            VTf.write(str(title) + '\n')
    with open('inf.txt', 'w') as inff:
        inff.write(str(lvl))

url0 = '/wiki/Google'
# initiate(url0)
maakBoom(100)




