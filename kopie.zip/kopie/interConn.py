import networkx as nx
from wikiClass import Node
import matplotlib.pyplot as plt

def openProgress():
    # Retreive progress
    #
    with open('V.txt', 'r') as Vf:
        V = [line.strip() for line in Vf.readlines()]
    with open('Vready.txt', 'r') as Vrf:
        Vready = [line.strip() for line in Vrf.readlines()]
    with open('Q.txt', 'r') as Qf:
        Q = [line.strip() for line in Qf.readlines()]
    with open('interA.txt', 'r') as Af:
        A = [eval(line.strip()) for line in Af.readlines()]
    with open('VT.txt', 'r') as VTf:
        VT = [line.strip() for line in VTf.readlines()]
        len0 = len(VT)
    with open('inf.txt', 'r') as inff:
        lvl = eval(inff.read())

    return V, Vready, Q, A, VT, len0, lvl

V, Vready, Q, interA, VT, len0, lvl = openProgress()


for v_ext in V:
    if v_ext not in Vready:
        v = Node(v_ext)

        with open('Vready.txt', 'a') as Vrf:
            Vrf.write(str(v_ext) + '\n')

        children = v.children
        print(v.title)
        try:
            for w in children:
                if (v_ext, w) not in interA:
                    interA.append((v_ext, w))
                    with open('interA.txt', 'a') as Af:
                        Af.write(str(f"{(v_ext, w)}") + '\n')
        except TypeError:
            continue

with open('interA.txt', 'w') as Af:
    for edge in interA:
        Af.write(str(edge) + '\n')

