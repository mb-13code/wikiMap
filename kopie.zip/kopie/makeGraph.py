import networkx as nx
from wikiClass import Node
import matplotlib.pyplot as plt

def openProgress():
    # Retreive progress
    #
    with open('V.txt', 'r') as Vf:
        V = [line.strip() for line in Vf.readlines()]
    with open('Q.txt', 'r') as Qf:
        Q = [line.strip() for line in Qf.readlines()]
    with open('interA.txt', 'r') as Af:
        A = [eval(line.strip()) for line in Af.readlines()]
    with open('VT.txt', 'r') as VTf:
        VT = [line.strip() for line in VTf.readlines()]
        len0 = len(VT)
    with open('inf.txt', 'r') as inff:
        lvl = eval(inff.read())

    return V, Q, A, VT, len0, lvl

V, Q, A, VT, len0, lvl = openProgress()

def drawGraphG(labels, tot=None):
    G = nx.Graph()
    G.add_nodes_from(V[:tot])
    G.add_edges_from(A[:tot])

    options = {
        'node_color': 'black',
        'node_size': 1,
        'width': 0.05,
        'labels': labels,
        'font_color': 'red',
        'font_size': 6,
        'label': f"{V[0][6:]} - V: {len(V)}, A: {len(A)}",
        'edge_color': (0.1, 0.1, 0.1, 0.2)
    }

    nx.draw(G, **options)
    plt.show()


def getLabelsPlus(N, tot=None):
    labels = {}
    count = {}

    for node in V[:tot]:
        node_count = 0
        for edge in A[:tot]:
            if node in edge:
                node_count += 1
        count[node] = node_count


    for node in count.keys():
        if count[node] >= N:
            labels[node] = node[6:]
    print(labels)
    return labels


drawGraphG(getLabelsPlus(1250))


